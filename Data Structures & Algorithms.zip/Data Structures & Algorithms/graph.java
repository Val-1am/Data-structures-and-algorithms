import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

class Graph {
    private int vertices;
    private List<List<GraphEdge>> adjacencyList;

    public Graph(int vertices) {
        this.vertices = vertices;
        this.adjacencyList = new ArrayList<>(vertices);
        for (int i = 0; i < vertices; i++) {
            this.adjacencyList.add(new ArrayList<>());
        }
    }

    public String getSiteName(int site) 
    {
        switch (site) {
            case 0:
                return "Entrance";
            case 1:
                return "Reptile Exhibit";
            case 2:
                return "Tiger Enclosure";
            case 3:
                return "Snow Leapords";
            case 4:
                return "Rhino Enclosure";
            case 5:
                return "Seal enclosure";
            case 6:
                return "Gift Shop";
            default:
                return "Exit";
        }
    }
    public void addEdge(int src, int dest, int weight) {
        GraphEdge edge = new GraphEdge(src, dest, weight);
        adjacencyList.get(src).add(edge);

    }

    public void printGraph() {
        for (int i = 0; i < vertices; i++) {
            System.out.print("Vertex " + i + " is connected to: ");
            for (GraphEdge edge : adjacencyList.get(i)) {
                System.out.print(edge.toString() + " ");
            }
            System.out.println();
        }
    }

    public static Graph openFile(String filePath) throws FileNotFoundException {
        File file = new File(filePath);
        Scanner scanner = new Scanner(file);

        int vertices = scanner.nextInt();
        Graph graph = new Graph(vertices);

        while (scanner.hasNext()) {
            int src = scanner.nextInt();
            int dest = scanner.nextInt();
            int weight = scanner.nextInt();
            graph.addEdge(src, dest, weight);
        }

        scanner.close();
        return graph;
    }

    public boolean searchSite(int site) 
    {
        for (int i = 0; i < vertices; i++) {
            for (GraphEdge edge : adjacencyList.get(i)) {
                if (edge.src == site || edge.dest == site) {
                    System.out.println("Site " + site + " has been found in our graph. You have found the");
                    return true;
                }
            }
        }
        System.out.println("Site " + site + " has not been found in our graph.");
        return false;
    }
    public boolean searchEdge(int edgeWeight) 
    {
        for (int i = 0; i < vertices; i++) {
            for (GraphEdge edge : adjacencyList.get(i)) {
                if (edge.weight == edgeWeight) {
                    System.out.println("Edge Found: " + edge.toString());
                    return true;
                }
            }
        }
        System.out.println("Edge not found.");
        return false;
    }
    // Inside the Graph class
    public void showConnected(int site) 
    {
        System.out.print("Sites connected to Site " + site + ": ");
        for (GraphEdge edge : adjacencyList.get(site)) {
            System.out.print(edge.dest + " ");
        }
        System.out.println();
    }

    
}

class GraphEdge implements Comparable<GraphEdge> {
    int src, dest, weight;

    public GraphEdge(int src, int dest, int weight) {
        this.src = src;
        this.dest = dest;
        this.weight = weight;
    }

    public int compareTo(GraphEdge other) {
        return Integer.compare(this.weight, other.weight);
    }

    public String toString() {
        return "(" + src + "->" + dest + ", weight=" + weight + ")";
    }
}