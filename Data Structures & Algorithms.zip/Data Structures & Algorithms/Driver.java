import java.util.*;

public class Driver {
    public static void main(String[] args) {

        Graph graph = new Graph(100); // initializing graph object to have 7 vertices
        Scanner scanner = new Scanner(System.in);

        int choice;
        String filePath;
        int src;
        int dest;
        int weight;

        // handles initialization of all sites edges and how much weight they carry

        graph.addEdge(0, 1, 1);
        graph.addEdge(0, 2, 6);
        graph.addEdge(1, 3, 8);
        graph.addEdge(1, 4, 7);
        graph.addEdge(1, 5, 26);
        graph.addEdge(2, 3, 3);
        graph.addEdge(2, 7, 17);
        graph.addEdge(3, 1, 13);
        graph.addEdge(3, 2, 9);
        graph.addEdge(3, 7, 19);
        graph.addEdge(4, 1, 24);
        graph.addEdge(4, 5, 2);
        graph.addEdge(4, 7, 7);
        graph.addEdge(5, 1, 19);
        graph.addEdge(5, 4, 6);
        graph.addEdge(6, 2, 13);
        graph.addEdge(6, 7, 4);
        graph.addEdge(7, 4, 20);
        graph.addEdge(7, 3, 29);
        graph.addEdge(7, 6, 2);

        System.out.println("Hello and welcome to our virtual console-driven tour of Dublin Zoo!");
        System.out.println("Listed below are all our exhibits and their respected vertices, have fun exploring which exhibit connects to where and how long it takes to get from place to place!");

        System.out.println("1. Open and input a graph from an external file");
        System.out.println("2. Search for a site");
        System.out.println("3. Insert an edge");
        System.out.println("4. Search for an edge");
        System.out.println("5. Display all sites connected to a given site");
        System.out.println("6. Display the closest site to a given site");
        System.out.println("7. Exit");
        System.out.print("Enter your choice: ");

        choice = scanner.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Please enter the File Path: ");
                filePath = scanner.nextLine();
                try {
                    graph = Graph.openFile(filePath); // overrides initial graph, will use this from now on
                    System.out.println("Graph loaded successfully from the file.");
                } catch (Exception e) {
                    System.out.println("Error loading the graph from the file");
                }
                break;
            case 2:
                System.out.println("Please enter the site you would like to look for: ");
                choice = scanner.nextInt();
                graph.searchSite(choice);
                System.out.print(graph.getSiteName(choice));
                break;

            case 3:
                System.out.println("Please enter the source: ");
                src = scanner.nextInt();
                System.out.println("Please enter the destination");
                dest = scanner.nextInt();
                System.out.println("Please enter the weight");
                weight = scanner.nextInt();
                graph.addEdge(src, dest, weight);
                break;

            case 4:
                System.out.println("Please enter the edge you are looking for");
                weight = scanner.nextInt();
                graph.searchEdge(weight);
                break;

            case 5:
                System.out.println("Please enter the site: ");
                src = scanner.nextInt();
                graph.showConnected(src);
                break;

            case 6:



        }
    }
}
